package scs.helloworld;

import org.springframework.boot.SpringApplication;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
    	//SpringApplication.run(HelloworldController.class, args);
    	//SpringApplication.run(AdditionController.class, args);
    	SpringApplication.run(EmployeeController.class, args);
    }
}
