package scs.helloworld;

import org.springframework.stereotype.Repository;
import java.util.Iterator;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.springframework.stereotype.Repository;
@Repository
public class EmpDao {
	 private static Employees list
     = new Employees();

	public Employees getAllEmployees()
	 {
		     Configuration cfg = new Configuration();
			cfg.configure("hibernate.cfg.xml");
			SessionFactory sf = cfg.buildSessionFactory();
			Session s = sf.openSession();
			Query q = s.createQuery("from Emp e");
			List lst =   q.list();
			Iterator it = lst.iterator();
			while(it.hasNext())
			{
				
				Emp emp =(Emp) it.next();
				list.getEmployeeList().add(emp);
			}
			sf.close();
			s.close();
	     return list;
	 }
	 public void addEmployee(Emp employee)
	  {
		    Configuration cfg = new Configuration();
			cfg.configure("hibernate.cfg.xml");
			SessionFactory sf = cfg.buildSessionFactory();
			Session s = sf.openSession();
			Transaction tx = s.beginTransaction();
		
			s.save(employee);
			tx.commit();
			s.close();
			
	       
	  }
}
