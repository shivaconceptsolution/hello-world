package scs.helloworld;

import java.util.ArrayList;
import java.util.List;

public class Employees {
	private List<Emp> employeeList;
	  
    // Method to return the list
    // of employees
    public List<Emp> getEmployeeList()
    {
  
        if (employeeList == null) {
  
            employeeList = new ArrayList<Emp>();
  
                   
        }
  
        return employeeList;
  
           
    }
  
    public void
    setEmployeeList(
        List<Emp> employeeList)
    {
        this.employeeList
            = employeeList;
    }
}
