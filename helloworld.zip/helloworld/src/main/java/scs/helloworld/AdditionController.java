package scs.helloworld;

import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
@EnableAutoConfiguration
public class AdditionController {
	@RequestMapping("/add")
	@ResponseBody
	public String addition() {
		int a=10,b=20,c;
		c=a+b;
	return "Result is !"+c;
	}
}
